export type PrintArea = {
  height: number;
  width: number;
  x: number;
  y: number;
};

export type PrintFit = "contain" | "cover" | "stretch" | "original_scale";

export type PrintAnchor =
  | "center"
  | "top_left"
  | "top"
  | "top_right"
  | "left"
  | "right"
  | "bottom_left"
  | "bottom"
  | "bottom_right";

export type MockupScene = {
  anchor: PrintAnchor;
  background_url: string;
  fit: PrintFit;
  name: string;
  need_print: boolean;
  offset_x: number;
  offset_y: number;
  output_height: number;
  output_width: number;
  print_area?: PrintArea;
  rotation: number;
  scale: number;
};

function isPositiveNumber(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}

function isNonNegativeNumber(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) && value >= 0;
}

function isPrintFit(value: unknown): value is PrintFit {
  return value === "contain" || value === "cover" || value === "stretch" || value === "original_scale";
}

function isPrintAnchor(value: unknown): value is PrintAnchor {
  return (
    value === "center" ||
    value === "top_left" ||
    value === "top" ||
    value === "top_right" ||
    value === "left" ||
    value === "right" ||
    value === "bottom_left" ||
    value === "bottom" ||
    value === "bottom_right"
  );
}

function optionalNumber(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function validatePrintArea(value: unknown, sceneIndex: number): PrintArea {
  if (!value || typeof value !== "object") {
    throw new Error(`第 ${sceneIndex + 1} 个场景缺少 print_area`);
  }

  const printArea = value as Record<string, unknown>;

  if (
    !isNonNegativeNumber(printArea.x) ||
    !isNonNegativeNumber(printArea.y) ||
    !isPositiveNumber(printArea.width) ||
    !isPositiveNumber(printArea.height)
  ) {
    throw new Error(`第 ${sceneIndex + 1} 个场景的 print_area 坐标不合法`);
  }

  const x = printArea.x as number;
  const y = printArea.y as number;
  const width = printArea.width as number;
  const height = printArea.height as number;

  return {
    height,
    width,
    x,
    y,
  };
}

function validatePrintAreaBounds(
  printArea: PrintArea,
  outputWidth: number,
  outputHeight: number,
  sceneIndex: number,
) {
  if (printArea.width < 10 || printArea.height < 10) {
    throw new Error(`第 ${sceneIndex + 1} 个场景：印花区域过小，可能导致图案显示异常。`);
  }

  if (
    printArea.x < 0 ||
    printArea.y < 0 ||
    printArea.x + printArea.width > outputWidth ||
    printArea.y + printArea.height > outputHeight
  ) {
    throw new Error(`第 ${sceneIndex + 1} 个场景：印花区域超出套图画布，请检查模板坐标。`);
  }
}

export function parseScenesJson(value: string): MockupScene[] {
  let parsed: unknown;

  try {
    parsed = JSON.parse(value);
  } catch {
    throw new Error("scenes JSON 格式不正确");
  }

  return validateScenes(parsed);
}

export function validateScenes(value: unknown): MockupScene[] {
  if (!Array.isArray(value) || value.length === 0) {
    throw new Error("scenes 必须是非空数组");
  }

  return value.map((item, index) => {
    if (!item || typeof item !== "object") {
      throw new Error(`第 ${index + 1} 个场景不是对象`);
    }

    const scene = item as Record<string, unknown>;

    if (typeof scene.name !== "string" || scene.name.trim().length === 0) {
      throw new Error(`第 ${index + 1} 个场景缺少 name`);
    }

    if (typeof scene.background_url !== "string" || scene.background_url.trim().length === 0) {
      throw new Error(`第 ${index + 1} 个场景缺少 background_url`);
    }

    if (typeof scene.need_print !== "boolean") {
      throw new Error(`第 ${index + 1} 个场景缺少 need_print`);
    }

    if (!isPositiveNumber(scene.output_width) || !isPositiveNumber(scene.output_height)) {
      throw new Error(`第 ${index + 1} 个场景的输出尺寸不合法`);
    }

    const outputWidth = Math.round(scene.output_width as number);
    const outputHeight = Math.round(scene.output_height as number);

    if (outputWidth > 8000 || outputHeight > 8000) {
      throw new Error(`第 ${index + 1} 个场景输出尺寸不能超过 8000`);
    }

    const validatedScene: MockupScene = {
      anchor: isPrintAnchor(scene.anchor) ? scene.anchor : "center",
      background_url: scene.background_url.trim(),
      fit: isPrintFit(scene.fit) ? scene.fit : "contain",
      name: scene.name.trim(),
      need_print: scene.need_print,
      offset_x: optionalNumber(scene.offset_x, 0),
      offset_y: optionalNumber(scene.offset_y, 0),
      output_height: outputHeight,
      output_width: outputWidth,
      rotation: optionalNumber(scene.rotation, 0),
      scale: Math.max(0.01, optionalNumber(scene.scale, 1)),
    };

    if (scene.need_print) {
      validatedScene.print_area = validatePrintArea(scene.print_area, index);
      validatePrintAreaBounds(validatedScene.print_area, outputWidth, outputHeight, index);
    }

    return validatedScene;
  });
}

export const sampleScenes: MockupScene[] = [
  {
    anchor: "center",
    background_url: "https://example.com/main.jpg",
    fit: "contain",
    name: "主图",
    need_print: true,
    offset_x: 0,
    offset_y: 0,
    output_height: 2000,
    output_width: 2000,
    print_area: {
      height: 600,
      width: 500,
      x: 400,
      y: 300,
    },
    rotation: 0,
    scale: 1,
  },
  {
    anchor: "center",
    background_url: "https://example.com/size.jpg",
    fit: "contain",
    name: "尺码图",
    need_print: false,
    offset_x: 0,
    offset_y: 0,
    output_height: 2000,
    output_width: 2000,
    rotation: 0,
    scale: 1,
  },
];
