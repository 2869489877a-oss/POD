import type { PrintArea } from "@/lib/mockups/scenes";

export type PrintFit = "contain" | "cover" | "stretch" | "original_scale";

export type PrintAnchor =
  | "center"
  | "top_left"
  | "top"
  | "top_right"
  | "left"
  | "right"
  | "bottom_left"
  | "bottom"
  | "bottom_right";

export type CalculatePrintPlacementInput = {
  anchor?: PrintAnchor;
  fit?: PrintFit;
  offsetX?: number;
  offsetY?: number;
  printArea: PrintArea;
  printHeight: number;
  printWidth: number;
  scale?: number;
};

export type PrintPlacement = {
  height: number;
  left: number;
  top: number;
  width: number;
};

function safeNumber(value: number | undefined, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function getAnchorOffset(anchor: PrintAnchor, areaWidth: number, areaHeight: number, width: number, height: number) {
  switch (anchor) {
    case "top_left":
      return { x: 0, y: 0 };
    case "top":
      return { x: (areaWidth - width) / 2, y: 0 };
    case "top_right":
      return { x: areaWidth - width, y: 0 };
    case "left":
      return { x: 0, y: (areaHeight - height) / 2 };
    case "right":
      return { x: areaWidth - width, y: (areaHeight - height) / 2 };
    case "bottom_left":
      return { x: 0, y: areaHeight - height };
    case "bottom":
      return { x: (areaWidth - width) / 2, y: areaHeight - height };
    case "bottom_right":
      return { x: areaWidth - width, y: areaHeight - height };
    case "center":
    default:
      return { x: (areaWidth - width) / 2, y: (areaHeight - height) / 2 };
  }
}

export function calculatePrintPlacement({
  anchor = "center",
  fit = "contain",
  offsetX = 0,
  offsetY = 0,
  printArea,
  printHeight,
  printWidth,
  scale = 1,
}: CalculatePrintPlacementInput): PrintPlacement {
  const safeScale = Math.max(0.01, safeNumber(scale, 1));
  const areaWidth = Math.max(1, printArea.width);
  const areaHeight = Math.max(1, printArea.height);
  const sourceWidth = Math.max(1, printWidth);
  const sourceHeight = Math.max(1, printHeight);
  let width = areaWidth;
  let height = areaHeight;

  if (fit === "contain") {
    const ratio = Math.min(areaWidth / sourceWidth, areaHeight / sourceHeight) * safeScale;
    width = sourceWidth * ratio;
    height = sourceHeight * ratio;
  } else if (fit === "cover") {
    width = areaWidth * safeScale;
    height = areaHeight * safeScale;
  } else if (fit === "original_scale") {
    width = sourceWidth * safeScale;
    height = sourceHeight * safeScale;
  } else {
    width = areaWidth * safeScale;
    height = areaHeight * safeScale;
  }

  const anchorOffset = getAnchorOffset(anchor, areaWidth, areaHeight, width, height);

  return {
    height: Math.max(1, Math.round(height)),
    left: Math.round(printArea.x + anchorOffset.x + safeNumber(offsetX, 0)),
    top: Math.round(printArea.y + anchorOffset.y + safeNumber(offsetY, 0)),
    width: Math.max(1, Math.round(width)),
  };
}
