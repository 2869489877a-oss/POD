import {
  colorDistance,
  estimateDominantEdgeColors,
  estimateEdgeBackgroundColor,
  getLuminance,
  getSaturation,
} from "@/lib/image-ai/color";
import {
  componentCenterScore,
  componentTouchesEdge,
  getMaskBBox,
  keepLargestComponents,
  keepScoredComponents,
  removeSmallComponents,
} from "@/lib/image-ai/components";
import { cropBufferByBBox } from "@/lib/image-ai/crop";
import { downloadImageBuffer, loadImagePixels, normalizeImage } from "@/lib/image-ai/image-buffer";
import { applyAlphaMask, combineMasks, invertMask, maskStats } from "@/lib/image-ai/mask";
import { closeMask, featherMask } from "@/lib/image-ai/morphology";
import { makeMaskPng, makeWhitePreview, rgbaToPng } from "@/lib/image-ai/output";
import type {
  ConnectedComponent,
  CutoutImageInput,
  CutoutImageResult,
  CutoutMode,
  ProcessingBBox,
  RgbColor,
} from "@/lib/image-ai/types";

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function pixelColor(data: Buffer, pixelIndex: number): RgbColor {
  const index = pixelIndex * 4;

  return {
    b: data[index + 2] ?? 0,
    g: data[index + 1] ?? 0,
    r: data[index] ?? 0,
  };
}

function pixelMatchesBackground(data: Buffer, pixelIndex: number, backgroundColor: RgbColor, tolerance: number): boolean {
  const alpha = data[pixelIndex * 4 + 3] ?? 255;

  if (alpha < 16) {
    return true;
  }

  return colorDistance(pixelColor(data, pixelIndex), backgroundColor) <= tolerance;
}

function getBackgroundColor(mode: CutoutMode, data: Buffer, width: number, height: number): RgbColor {
  if (mode === "white_background") {
    return { b: 255, g: 255, r: 255 };
  }

  if (mode === "black_background") {
    return { b: 0, g: 0, r: 0 };
  }

  return estimateEdgeBackgroundColor(data, width, height);
}

function getLocalContrast(data: Buffer, width: number, height: number, x: number, y: number, luminance: number): number {
  let maxDelta = 0;
  const neighbors = [
    [x - 1, y],
    [x + 1, y],
    [x, y - 1],
    [x, y + 1],
  ];

  for (const [nextX, nextY] of neighbors) {
    if (nextX < 0 || nextY < 0 || nextX >= width || nextY >= height) {
      continue;
    }

    const nextIndex = (nextY * width + nextX) * 4;
    const nextLuminance = getLuminance(
      data[nextIndex] ?? 0,
      data[nextIndex + 1] ?? 0,
      data[nextIndex + 2] ?? 0,
    );

    maxDelta = Math.max(maxDelta, Math.abs(luminance - nextLuminance));
  }

  return maxDelta;
}

function isCenterBiasedPixel(width: number, height: number, x: number, y: number): boolean {
  return x > width * 0.08 && x < width * 0.92 && y > height * 0.06 && y < height * 0.94;
}

function createEdgeFloodBackgroundMask(
  data: Buffer,
  width: number,
  height: number,
  backgroundColor: RgbColor,
  tolerance: number,
): Uint8Array {
  const backgroundMask = new Uint8Array(width * height);
  const queue = new Int32Array(width * height);
  let readIndex = 0;
  let writeIndex = 0;

  function addSeed(pixelIndex: number) {
    if (backgroundMask[pixelIndex] > 0) {
      return;
    }

    if (!pixelMatchesBackground(data, pixelIndex, backgroundColor, tolerance)) {
      return;
    }

    backgroundMask[pixelIndex] = 255;
    queue[writeIndex] = pixelIndex;
    writeIndex += 1;
  }

  for (let x = 0; x < width; x += 1) {
    addSeed(x);
    addSeed((height - 1) * width + x);
  }

  for (let y = 0; y < height; y += 1) {
    addSeed(y * width);
    addSeed(y * width + width - 1);
  }

  while (readIndex < writeIndex) {
    const pixelIndex = queue[readIndex];
    readIndex += 1;

    const x = pixelIndex % width;
    const y = Math.floor(pixelIndex / width);
    const neighbors = [pixelIndex - 1, pixelIndex + 1, pixelIndex - width, pixelIndex + width];

    for (const nextIndex of neighbors) {
      if (nextIndex < 0 || nextIndex >= backgroundMask.length || backgroundMask[nextIndex] > 0) {
        continue;
      }

      const nextX = nextIndex % width;
      const nextY = Math.floor(nextIndex / width);

      if (Math.abs(nextX - x) + Math.abs(nextY - y) !== 1) {
        continue;
      }

      if (!pixelMatchesBackground(data, nextIndex, backgroundColor, tolerance)) {
        continue;
      }

      backgroundMask[nextIndex] = 255;
      queue[writeIndex] = nextIndex;
      writeIndex += 1;
    }
  }

  return backgroundMask;
}

function createMultiEdgeFloodBackgroundMask(
  data: Buffer,
  width: number,
  height: number,
  mode: CutoutMode,
  fallbackColor: RgbColor,
  tolerance: number,
): Uint8Array {
  if (mode === "white_background" || mode === "black_background") {
    return createEdgeFloodBackgroundMask(data, width, height, fallbackColor, tolerance);
  }

  const edgeColors = estimateDominantEdgeColors(data, width, height)
    .filter((bucket) => bucket.count >= 2)
    .slice(0, mode === "similar_background" || mode === "subject_cutout" ? 5 : 3)
    .map((bucket) => bucket.color);
  const colors = edgeColors.length > 0 ? edgeColors : [fallbackColor];
  let output = createEdgeFloodBackgroundMask(data, width, height, colors[0], tolerance);

  for (const color of colors.slice(1)) {
    output = combineMasks(
      output,
      createEdgeFloodBackgroundMask(data, width, height, color, tolerance),
      "or",
    );
  }

  return output;
}

function createSubjectCandidateMask(
  data: Buffer,
  width: number,
  height: number,
  backgroundColor: RgbColor,
  tolerance: number,
  mode: CutoutMode,
): Uint8Array {
  const mask = new Uint8Array(width * height);
  const backgroundLuminance = getLuminance(backgroundColor.r, backgroundColor.g, backgroundColor.b);
  const isCartoonMode = mode === "cartoon_subject";
  const isSimilarBackgroundMode = mode === "similar_background" || mode === "subject_cutout";
  const isSubjectCutoutMode = mode === "subject_cutout";

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const pixelIndex = y * width + x;
      const alpha = data[pixelIndex * 4 + 3] ?? 255;

      if (alpha < 16) {
        continue;
      }

      const color = pixelColor(data, pixelIndex);
      const luminance = getLuminance(color.r, color.g, color.b);
      const saturation = getSaturation(color.r, color.g, color.b);
      const distance = colorDistance(color, backgroundColor);
      const luminanceDelta = Math.abs(luminance - backgroundLuminance);
      const localContrast = getLocalContrast(data, width, height, x, y, luminance);
      const centerBiased = isCenterBiasedPixel(width, height, x, y);
      const highSaturationSubject =
        saturation > (isCartoonMode || isSubjectCutoutMode ? 0.18 : 0.28) &&
        (distance > tolerance * 0.45 || localContrast > 18);
      const outlineSubject = luminance < 72 && (distance > 24 || localContrast > 24);
      const brightSubject = luminance > 220 && (distance > 42 || localContrast > 28);
      const contrastSubject =
        distance > tolerance + (isSimilarBackgroundMode ? 6 : 16) ||
        luminanceDelta > (isSimilarBackgroundMode ? 38 : 54);
      const edgeSubject =
        localContrast > (isCartoonMode || isSubjectCutoutMode ? 18 : 34) &&
        (distance > 14 || centerBiased);

      if (
        highSaturationSubject ||
        outlineSubject ||
        brightSubject ||
        contrastSubject ||
        edgeSubject ||
        (centerBiased && isSimilarBackgroundMode && (distance > tolerance * 0.62 || localContrast > 16))
      ) {
        mask[pixelIndex] = 255;
      }
    }
  }

  return mask;
}

function scoreCenteredComponent(width: number, height: number) {
  return (component: ConnectedComponent) => {
    const centerScore = componentCenterScore(component, width, height);
    const areaRatio = component.area / (width * height);
    const bboxAreaRatio = (component.bbox.width * component.bbox.height) / (width * height);
    const reasonableAreaScore = areaRatio > 0.001 && areaRatio < 0.88 ? 1 : 0.25;
    const bboxPenalty = bboxAreaRatio > 0.94 ? 0.2 : 1;
    const edgePenalty = componentTouchesEdge(component, width, height, Math.round(Math.min(width, height) * 0.02))
      ? areaRatio > 0.08
        ? 0.18
        : 0.55
      : 1;

    return component.area * (0.55 + centerScore * 0.45) * reasonableAreaScore * bboxPenalty * edgePenalty;
  };
}

function validateCutoutMask(mask: Uint8Array, width: number, height: number, bbox: ProcessingBBox, mode: CutoutMode) {
  const stats = maskStats(mask);
  const maxRatio = mode === "subject_cutout" ? 0.96 : 0.98;

  if (stats.ratio < 0.002) {
    throw new Error("抠图失败：检测到的主体区域过小");
  }

  if (stats.ratio > maxRatio) {
    throw new Error("抠图失败：检测到的主体区域过大，背景识别不可靠");
  }

  if (bbox.width <= 0 || bbox.height <= 0 || bbox.width > width || bbox.height > height) {
    throw new Error("抠图失败：主体边界框无效");
  }

  return stats;
}

export async function cutoutImage(input: CutoutImageInput): Promise<CutoutImageResult> {
  const maxSize = input.options?.maxSize ?? 1800;
  const tolerance = input.options?.tolerance ?? 42;
  const featherRadius = input.options?.featherRadius ?? 1;
  const padding = input.options?.padding ?? 8;
  const cropToContent = input.options?.cropToContent ?? true;

  const originalBuffer = await downloadImageBuffer(input.imageUrl);
  const normalizedBuffer = await normalizeImage(originalBuffer, maxSize);
  const { data, height, width } = await loadImagePixels(normalizedBuffer);
  const backgroundColor = getBackgroundColor(input.mode, data, width, height);
  const effectiveTolerance =
    input.mode === "auto_background" || input.mode === "cartoon_subject"
      ? Math.max(tolerance, 46)
      : input.mode === "similar_background" || input.mode === "subject_cutout"
        ? Math.max(18, tolerance)
        : tolerance;
  const backgroundMask = createMultiEdgeFloodBackgroundMask(
    data,
    width,
    height,
    input.mode,
    backgroundColor,
    effectiveTolerance,
  );
  const subjectCandidateMask = createSubjectCandidateMask(
    data,
    width,
    height,
    backgroundColor,
    effectiveTolerance,
    input.mode,
  );
  let keepMask = invertMask(backgroundMask);
  const minArea = Math.max(32, Math.floor(width * height * 0.00008));

  if (
    input.mode === "auto_background" ||
    input.mode === "solid_background" ||
    input.mode === "cartoon_subject" ||
    input.mode === "similar_background" ||
    input.mode === "subject_cutout"
  ) {
    keepMask = combineMasks(keepMask, subjectCandidateMask, "or");
  }

  if (
    (input.mode === "subject_cutout" || maskStats(keepMask).ratio > 0.94) &&
    maskStats(subjectCandidateMask).ratio > 0.002
  ) {
    keepMask = subjectCandidateMask;
  }

  keepMask = removeSmallComponents(keepMask, width, height, minArea);
  keepMask =
    input.mode === "cartoon_subject" || input.mode === "similar_background" || input.mode === "subject_cutout"
      ? keepScoredComponents(keepMask, width, height, 10, scoreCenteredComponent(width, height))
      : keepLargestComponents(keepMask, width, height, 8);
  keepMask = closeMask(keepMask, width, height, 1);

  const bbox = getMaskBBox(keepMask, width, height, padding);
  const stats = validateCutoutMask(keepMask, width, height, bbox, input.mode);
  const outputMask = featherRadius > 0 ? featherMask(keepMask, width, height, featherRadius) : keepMask;
  const cutoutData = applyAlphaMask(data, width, height, outputMask);
  let cutoutPng = await rgbaToPng(cutoutData, width, height);
  let maskPng = await makeMaskPng(outputMask, width, height);
  let outputWidth = width;
  let outputHeight = height;

  if (cropToContent) {
    cutoutPng = await cropBufferByBBox(cutoutPng, bbox);
    maskPng = await cropBufferByBBox(maskPng, bbox);
    outputWidth = bbox.width;
    outputHeight = bbox.height;
  }

  const previewJpg = await makeWhitePreview(cutoutPng);
  const bboxAreaRatio = (bbox.width * bbox.height) / (width * height);
  const confidence = clamp(
    1 -
      Math.abs(stats.ratio - (input.mode === "subject_cutout" ? 0.42 : 0.35)) -
      (bboxAreaRatio > 0.9 ? 0.25 : 0),
    0,
    1,
  );

  return {
    bbox,
    cutoutPng,
    height: outputHeight,
    maskPng,
    metrics: {
      backgroundColor,
      bboxAreaRatio,
      confidence,
      maskAreaRatio: stats.ratio,
      mode: input.mode,
      selectedStrategy: input.mode === "subject_cutout" ? "subject_cutout" : "edge_flood_fill",
      tolerance: effectiveTolerance,
      warning: confidence < 0.45 ? "low_confidence" : null,
    },
    previewJpg,
    width: outputWidth,
  };
}
