export type ImageDerivativeType =
  | "print_extract_raw"
  | "print_extract_final"
  | "cutout"
  | "mask"
  | "preview";

export type ImageDerivativeStatus = "pending" | "processing" | "completed" | "failed";

export type PrintExtractionMode =
  | "auto"
  | "light_garment"
  | "dark_garment"
  | "high_contrast"
  | "colorful_cartoon"
  | "center_design"
  | "subject_design"
  | "product_render"
  | "large_print"
  | "manual_rect";

export type CutoutMode =
  | "auto_background"
  | "white_background"
  | "black_background"
  | "solid_background"
  | "edge_flood_fill"
  | "subject_cutout"
  | "cartoon_subject"
  | "similar_background";

export type ProcessingBBox = {
  height: number;
  width: number;
  x: number;
  y: number;
};

export type ProcessingMetrics = {
  backgroundColor?: unknown;
  background_color?: unknown;
  bboxAreaRatio?: number;
  centerScore?: number;
  colorScore?: number;
  componentCount?: number;
  component_count?: number;
  confidence?: number;
  edgeScore?: number;
  garmentColor?: unknown;
  largestComponentArea?: number;
  maskAreaRatio?: number;
  mask_area?: number;
  mode?: string;
  processing_ms?: number;
  retained_area_ratio?: number;
  selectedStrategy?: string;
  tolerance?: number;
  warning?: string | null;
};

export type PrintExtractionOptions = {
  color_tolerance?: number;
  crop_to_bbox?: boolean;
  featherRadius?: number;
  feather_radius?: number;
  manualRect?: ProcessingBBox;
  manual_rect?: Partial<ProcessingBBox>;
  maxSize?: number;
  max_work_size?: number;
  minComponentArea?: number;
  min_component_area?: number;
  mode: PrintExtractionMode;
  padding?: number;
  preserveBlackInk?: boolean;
  preserveWhiteInk?: boolean;
};

export type CutoutOptions = {
  background_tolerance?: number;
  cropToContent?: boolean;
  crop_to_bbox?: boolean;
  edge_sample_size?: number;
  featherRadius?: number;
  feather_radius?: number;
  keep_shadow?: boolean;
  maxSize?: number;
  mode: CutoutMode;
  padding?: number;
  tolerance?: number;
};

export type ImageDerivative = {
  asset_id: string;
  bbox: ProcessingBBox;
  created_at: string;
  derivative_type: ImageDerivativeType;
  error_message: string | null;
  height: number | null;
  id: string;
  job_id: string | null;
  job_item_id: string | null;
  mask_url: string | null;
  metrics: ProcessingMetrics;
  options: CutoutOptions | PrintExtractionOptions | Record<string, unknown>;
  output_url: string | null;
  preview_url: string | null;
  source_url: string;
  status: ImageDerivativeStatus;
  updated_at: string;
  width: number | null;
};
