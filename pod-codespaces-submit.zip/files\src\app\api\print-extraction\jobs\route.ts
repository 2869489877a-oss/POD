import { randomUUID } from "crypto";

import { NextResponse } from "next/server";

import { extractPrintFromImage } from "@/lib/image-ai/print-extraction";
import type { PrintExtractionMode, ProcessingBBox } from "@/lib/image-ai/types";
import { createSupabaseServiceRoleClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

const ASSETS_BUCKET = "assets";

type SupabaseServiceClient = ReturnType<typeof createSupabaseServiceRoleClient>;

type AssetRecord = {
  filename: string | null;
  id: string;
  original_url: string | null;
};

type PrintExtractionJobRequest = {
  assetIds?: unknown;
  asset_ids?: unknown;
  manualRects?: unknown;
  manual_rect?: unknown;
  mode?: unknown;
  options?: unknown;
  setPreferred?: unknown;
  set_preferred?: unknown;
};

type CompletedPrintExtractionResult = {
  asset_id: string;
  derivative_id: string | null;
  error_message: null;
  filename: string | null;
  final_url: string;
  input_url: string;
  mask_url: string;
  metrics: Record<string, unknown>;
  preview_url: string;
  raw_url: string;
  suggestion: string | null;
  status: "completed";
};

type FailedPrintExtractionResult = {
  asset_id: string;
  error_message: string;
  final_url: null;
  filename?: string | null;
  mask_url: null;
  metrics: Record<string, unknown>;
  preview_url: null;
  suggestion: string | null;
  status: "failed";
};

type PrintExtractionResultItem = CompletedPrintExtractionResult | FailedPrintExtractionResult;

const allowedModes = new Set<PrintExtractionMode>([
  "auto",
  "light_garment",
  "dark_garment",
  "high_contrast",
  "colorful_cartoon",
  "center_design",
  "subject_design",
  "product_render",
  "large_print",
  "manual_rect",
]);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function getUniqueAssetIds(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return Array.from(
    new Set(value.filter((item): item is string => typeof item === "string" && item.length > 0)),
  );
}

function getMode(value: unknown): PrintExtractionMode | null {
  return typeof value === "string" && allowedModes.has(value as PrintExtractionMode)
    ? (value as PrintExtractionMode)
    : null;
}

function optionalNumber(value: unknown, fallback: number): number {
  if (value === null || value === undefined || value === "") {
    return fallback;
  }

  const numberValue = Number(value);
  return Number.isFinite(numberValue) ? numberValue : fallback;
}

function optionalBoolean(value: unknown, fallback: boolean): boolean {
  return typeof value === "boolean" ? value : fallback;
}

function dateFolder(): string {
  return new Date().toISOString().slice(0, 10);
}

function parseManualRect(value: unknown): ProcessingBBox | undefined {
  if (!isRecord(value)) {
    return undefined;
  }

  const x = Number(value.x);
  const y = Number(value.y);
  const width = Number(value.width);
  const height = Number(value.height);

  if (![x, y, width, height].every(Number.isFinite) || width <= 10 || height <= 10) {
    return undefined;
  }

  return { height, width, x, y };
}

function getPublicUrl(supabase: SupabaseServiceClient, path: string): string {
  return supabase.storage.from(ASSETS_BUCKET).getPublicUrl(path).data.publicUrl;
}

function normalizeProcessingError(error: unknown): string {
  const message = error instanceof Error ? error.message : "印花提取失败";

  if (message.includes("图片下载失败") || message.toLowerCase().includes("fetch failed")) {
    return message.includes("图片下载失败") ? message : "图片下载失败";
  }

  if (
    message.includes("unsupported image") ||
    message.includes("Input buffer contains unsupported image format") ||
    message.includes("不是有效图片")
  ) {
    return "图片不是有效图片";
  }

  return message;
}

function getSuggestion(errorMessage: string): string | null {
  if (errorMessage.includes("手动框选模式需要")) {
    return "请回到页面为该素材点击“框选印花区域”，保存坐标后再重新提交。";
  }

  if (errorMessage.includes("印花区域过大")) {
    return "建议使用手动框选模式，只框住胸前、背后或图案所在区域。";
  }

  if (errorMessage.includes("图案和衣服颜色过于接近")) {
    return "建议切换高对比模式，或用手动框选缩小处理范围。";
  }

  if (errorMessage.includes("背景和衣服颜色相似")) {
    return "建议使用手动框选模式，避免背景和衣服一起进入印花区域。";
  }

  if (errorMessage.includes("3D商品效果图") || errorMessage.includes("主体抠图")) {
    return "建议使用 3D/主体图案模式，或手动框选真实印花区域。";
  }

  if (errorMessage.includes("未检测到有效印花区域")) {
    return "建议尝试彩色卡通模式、深色衣服模式或手动框选模式。";
  }

  if (errorMessage.includes("图片下载失败")) {
    return "请检查原图 URL 是否可访问，或重新上传图片。";
  }

  if (errorMessage.includes("图片不是有效图片")) {
    return "请确认文件是 jpg、png 或 webp 图片后重新上传。";
  }

  return null;
}

async function uploadImage(
  supabase: SupabaseServiceClient,
  path: string,
  buffer: Buffer,
  contentType: string,
): Promise<string> {
  const { error } = await supabase.storage.from(ASSETS_BUCKET).upload(path, buffer, {
    cacheControl: "31536000",
    contentType,
    upsert: false,
  });

  if (error) {
    throw new Error(`Failed to upload generated image: ${error.message}`);
  }

  return getPublicUrl(supabase, path);
}

async function processAsset(
  supabase: SupabaseServiceClient,
  asset: AssetRecord,
  mode: PrintExtractionMode,
  manualRects: Record<string, unknown>,
  options: Record<string, unknown>,
  setPreferred: boolean,
): Promise<PrintExtractionResultItem> {
  try {
    if (!asset.original_url) {
      throw new Error("Asset is missing original_url");
    }

    const manualRect = mode === "manual_rect" ? parseManualRect(manualRects[asset.id]) : undefined;

    if (mode === "manual_rect" && !manualRect) {
      throw new Error("手动框选模式需要为该素材提供有效的框选区域");
    }

    const result = await extractPrintFromImage({
      imageUrl: asset.original_url,
      manualRect,
      mode,
      options: {
        featherRadius: optionalNumber(options.featherRadius, 1),
        maxSize: optionalNumber(options.maxSize, 1800),
        minComponentArea: optionalNumber(options.minComponentArea, 80),
        padding: optionalNumber(options.padding, 40),
        preserveBlackInk: optionalBoolean(options.preserveBlackInk, true),
        preserveWhiteInk: optionalBoolean(options.preserveWhiteInk, true),
      },
    });
    const folder = dateFolder();
    const id = randomUUID();
    const rawPath = `derivatives/${folder}/${id}-print-raw.png`;
    const finalPath = `derivatives/${folder}/${id}-print-final.png`;
    const previewPath = `derivatives/${folder}/${id}-preview.jpg`;
    const maskPath = `derivatives/${folder}/${id}-mask.png`;
    const [rawUrl, finalUrl, previewUrl, maskUrl] = await Promise.all([
      uploadImage(supabase, rawPath, result.rawPng, "image/png"),
      uploadImage(supabase, finalPath, result.finalPng, "image/png"),
      uploadImage(supabase, previewPath, result.previewJpg, "image/jpeg"),
      uploadImage(supabase, maskPath, result.maskPng, "image/png"),
    ]);

    const { data: derivativeRows, error: derivativeError } = await supabase
      .from("image_derivatives")
      .insert([
        {
          asset_id: asset.id,
          bbox: result.bbox,
          derivative_type: "print_extract_raw",
          height: result.height,
          mask_url: maskUrl,
          metrics: result.metrics,
          options: { manualRect, mode, ...options },
          output_url: rawUrl,
          preview_url: previewUrl,
          source_url: asset.original_url,
          status: "completed",
          width: result.width,
        },
        {
          asset_id: asset.id,
          bbox: result.bbox,
          derivative_type: "print_extract_final",
          height: result.height,
          mask_url: maskUrl,
          metrics: result.metrics,
          options: { manualRect, mode, ...options },
          output_url: finalUrl,
          preview_url: previewUrl,
          source_url: asset.original_url,
          status: "completed",
          width: result.width,
        },
        {
          asset_id: asset.id,
          bbox: result.bbox,
          derivative_type: "preview",
          height: result.height,
          metrics: result.metrics,
          options: { manualRect, mode, ...options },
          output_url: previewUrl,
          preview_url: previewUrl,
          source_url: asset.original_url,
          status: "completed",
          width: result.width,
        },
        {
          asset_id: asset.id,
          bbox: result.bbox,
          derivative_type: "mask",
          height: result.height,
          mask_url: maskUrl,
          metrics: result.metrics,
          options: { manualRect, mode, ...options },
          output_url: maskUrl,
          source_url: asset.original_url,
          status: "completed",
          width: result.width,
        },
      ])
      .select("id,derivative_type");

    if (derivativeError) {
      throw new Error(`Failed to save derivative rows: ${derivativeError.message}`);
    }

    const updatePayload = setPreferred
      ? { preferred_design_url: finalUrl, print_extract_url: finalUrl }
      : { print_extract_url: finalUrl };
    const { error: assetUpdateError } = await supabase.from("assets").update(updatePayload).eq("id", asset.id);

    if (assetUpdateError) {
      throw new Error(`Failed to update asset print_extract_url: ${assetUpdateError.message}`);
    }

    return {
      asset_id: asset.id,
      derivative_id: derivativeRows?.find((row) => row.derivative_type === "print_extract_final")?.id ?? null,
      error_message: null,
      filename: asset.filename,
      final_url: finalUrl,
      input_url: asset.original_url,
      mask_url: maskUrl,
      metrics: result.metrics,
      preview_url: previewUrl,
      raw_url: rawUrl,
      suggestion:
        typeof result.metrics.warning === "string"
          ? result.metrics.warning
          : typeof result.metrics.confidence === "number" && result.metrics.confidence < 0.45
            ? "结果可能不理想，建议切换模式或手动框选。"
            : null,
      status: "completed",
    };
  } catch (error) {
    const errorMessage = normalizeProcessingError(error);

    return {
      asset_id: asset.id,
      error_message: errorMessage,
      final_url: null,
      filename: asset.filename,
      mask_url: null,
      metrics: {},
      preview_url: null,
      suggestion: getSuggestion(errorMessage),
      status: "failed",
    };
  }
}

export async function POST(request: Request) {
  let body: PrintExtractionJobRequest;

  try {
    body = (await request.json()) as PrintExtractionJobRequest;
  } catch {
    return NextResponse.json({ error: "Invalid print extraction request body" }, { status: 400 });
  }

  const assetIds = getUniqueAssetIds(body.assetIds ?? body.asset_ids);
  const mode = getMode(body.mode);
  const manualRects = isRecord(body.manualRects) ? body.manualRects : {};
  const legacyManualRect = parseManualRect(body.manual_rect);
  const options = isRecord(body.options) ? body.options : {};
  const setPreferred = optionalBoolean(body.setPreferred ?? body.set_preferred, false);

  if (assetIds.length === 0) {
    return NextResponse.json({ error: "assetIds must contain at least one asset id" }, { status: 400 });
  }

  if (!mode) {
    return NextResponse.json({ error: "Invalid print extraction mode" }, { status: 400 });
  }

  if (legacyManualRect && assetIds.length > 0) {
    manualRects[assetIds[0]] = legacyManualRect;
  }

  try {
    const supabase = createSupabaseServiceRoleClient();
    const { data, error } = await supabase
      .from("assets")
      .select("id,filename,original_url")
      .in("id", assetIds);

    if (error) {
      throw new Error(`Failed to read assets: ${error.message}`);
    }

    const assetMap = new Map(((data ?? []) as AssetRecord[]).map((asset) => [asset.id, asset]));
    const results: PrintExtractionResultItem[] = [];

    for (const assetId of assetIds) {
      const asset = assetMap.get(assetId);

      if (!asset) {
        results.push({
          asset_id: assetId,
          error_message: "Asset record not found",
          final_url: null,
          mask_url: null,
          metrics: {},
          preview_url: null,
          suggestion: "请刷新素材列表后重试。",
          status: "failed",
        });
        continue;
      }

      results.push(await processAsset(supabase, asset, mode, manualRects, options, setPreferred));
    }

    const success = results.filter((result) => result.status === "completed").length;
    const failed = results.length - success;

    return NextResponse.json({
      failed,
      ok: true,
      results,
      success,
      total: results.length,
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to create print extraction job" },
      { status: 500 },
    );
  }
}
