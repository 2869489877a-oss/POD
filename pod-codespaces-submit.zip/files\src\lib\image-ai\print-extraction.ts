import {
  colorDistance,
  estimateDominantRegionColor,
  estimateEdgeBackgroundColor,
  getColorfulness,
  getLuminance,
  getSaturation,
  isNearBlack,
  isNearWhite,
} from "@/lib/image-ai/color";
import {
  componentCenterScore,
  componentTouchesEdge,
  findConnectedComponents,
  getMaskBBox,
  keepScoredComponents,
  removeSmallComponents,
} from "@/lib/image-ai/components";
import { cropBufferByBBox, safeBBox } from "@/lib/image-ai/crop";
import { downloadImageBuffer, loadImagePixels, normalizeImage } from "@/lib/image-ai/image-buffer";
import { applyAlphaMask, combineMasks, invertMask, maskStats } from "@/lib/image-ai/mask";
import { closeMask, featherMask } from "@/lib/image-ai/morphology";
import { makeMaskPng, makeWhitePreview, rgbaToPng } from "@/lib/image-ai/output";
import type {
  ConnectedComponent,
  PrintExtractionInput,
  PrintExtractionMode,
  PrintExtractionResult,
  ProcessingBBox,
  RgbColor,
} from "@/lib/image-ai/types";

type AutoStrategy =
  | "light_garment"
  | "dark_garment"
  | "high_contrast"
  | "colorful_cartoon"
  | "center_design"
  | "subject_design";

type StrategyMetrics = {
  bboxAreaRatio: number;
  centerScore: number;
  colorScore: number;
  componentCount: number;
  confidence: number;
  edgeScore: number;
  largestComponentArea: number;
  maskAreaRatio: number;
  warning?: string;
};

type StrategyResult = {
  backgroundColor: RgbColor;
  garmentColor: RgbColor;
  mask: Uint8Array;
  metrics: StrategyMetrics;
  selectedStrategy: AutoStrategy | "manual_rect";
};

type PixelFeatures = {
  backgroundDistance: number;
  colorfulness: number;
  garmentDistance: number;
  localContrast: number;
  luminance: number;
  saturation: number;
};

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function getPixel(data: Buffer, pixelIndex: number): RgbColor {
  const index = pixelIndex * 4;

  return {
    b: data[index + 2] ?? 0,
    g: data[index + 1] ?? 0,
    r: data[index] ?? 0,
  };
}

function getCenterDesignRegion(width: number, height: number): ProcessingBBox {
  const x = Math.round(width * 0.08);
  const y = Math.round(height * 0.08);
  const right = Math.round(width * 0.92);
  const bottom = Math.round(height * 0.88);

  return {
    height: Math.max(1, bottom - y),
    width: Math.max(1, right - x),
    x,
    y,
  };
}

function isInsideRegion(x: number, y: number, region: ProcessingBBox | null): boolean {
  if (!region) {
    return true;
  }

  return x >= region.x && y >= region.y && x < region.x + region.width && y < region.y + region.height;
}

function getLocalContrast(data: Buffer, width: number, height: number, x: number, y: number, luminance: number): number {
  let maxDelta = 0;
  const neighbors = [
    [x - 1, y],
    [x + 1, y],
    [x, y - 1],
    [x, y + 1],
  ];

  for (const [nextX, nextY] of neighbors) {
    if (nextX < 0 || nextY < 0 || nextX >= width || nextY >= height) {
      continue;
    }

    const nextIndex = (nextY * width + nextX) * 4;
    const nextLuminance = getLuminance(
      data[nextIndex] ?? 0,
      data[nextIndex + 1] ?? 0,
      data[nextIndex + 2] ?? 0,
    );

    maxDelta = Math.max(maxDelta, Math.abs(luminance - nextLuminance));
  }

  return maxDelta;
}

function getPixelFeatures(
  data: Buffer,
  width: number,
  height: number,
  pixelIndex: number,
  backgroundColor: RgbColor,
  garmentColor: RgbColor,
): PixelFeatures {
  const color = getPixel(data, pixelIndex);
  const x = pixelIndex % width;
  const y = Math.floor(pixelIndex / width);
  const luminance = getLuminance(color.r, color.g, color.b);

  return {
    backgroundDistance: colorDistance(color, backgroundColor),
    colorfulness: getColorfulness(color.r, color.g, color.b),
    garmentDistance: colorDistance(color, garmentColor),
    localContrast: getLocalContrast(data, width, height, x, y, luminance),
    luminance,
    saturation: getSaturation(color.r, color.g, color.b),
  };
}

function isGarmentBasePixel(features: PixelFeatures, color: RgbColor, garmentColor: RgbColor): boolean {
  const garmentLuminance = getLuminance(garmentColor.r, garmentColor.g, garmentColor.b);
  const whiteBase = garmentLuminance > 185 && isNearWhite(color.r, color.g, color.b, 38) && features.saturation < 0.12;
  const blackBase = garmentLuminance < 75 && isNearBlack(color.r, color.g, color.b, 42) && features.saturation < 0.18;

  return (whiteBase || blackBase) && features.garmentDistance < 42 && features.localContrast < 22;
}

function pixelMatchesColor(data: Buffer, pixelIndex: number, color: RgbColor, tolerance: number): boolean {
  const alpha = data[pixelIndex * 4 + 3] ?? 255;

  if (alpha < 16) {
    return true;
  }

  return colorDistance(getPixel(data, pixelIndex), color) <= tolerance;
}

function createEdgeFloodBackgroundMask(
  data: Buffer,
  width: number,
  height: number,
  backgroundColor: RgbColor,
  tolerance: number,
): Uint8Array {
  const mask = new Uint8Array(width * height);
  const queue = new Int32Array(width * height);
  let readIndex = 0;
  let writeIndex = 0;

  function addSeed(pixelIndex: number) {
    if (mask[pixelIndex] > 0 || !pixelMatchesColor(data, pixelIndex, backgroundColor, tolerance)) {
      return;
    }

    mask[pixelIndex] = 255;
    queue[writeIndex] = pixelIndex;
    writeIndex += 1;
  }

  for (let x = 0; x < width; x += 1) {
    addSeed(x);
    addSeed((height - 1) * width + x);
  }

  for (let y = 0; y < height; y += 1) {
    addSeed(y * width);
    addSeed(y * width + width - 1);
  }

  while (readIndex < writeIndex) {
    const pixelIndex = queue[readIndex];
    readIndex += 1;

    const x = pixelIndex % width;
    const y = Math.floor(pixelIndex / width);
    const neighbors = [pixelIndex - 1, pixelIndex + 1, pixelIndex - width, pixelIndex + width];

    for (const nextIndex of neighbors) {
      if (nextIndex < 0 || nextIndex >= mask.length || mask[nextIndex] > 0) {
        continue;
      }

      const nextX = nextIndex % width;
      const nextY = Math.floor(nextIndex / width);

      if (Math.abs(nextX - x) + Math.abs(nextY - y) !== 1) {
        continue;
      }

      if (!pixelMatchesColor(data, nextIndex, backgroundColor, tolerance)) {
        continue;
      }

      mask[nextIndex] = 255;
      queue[writeIndex] = nextIndex;
      writeIndex += 1;
    }
  }

  return mask;
}

function createManualRectMask(data: Buffer, width: number, height: number, region: ProcessingBBox): Uint8Array {
  const mask = new Uint8Array(width * height);

  for (let y = region.y; y < region.y + region.height; y += 1) {
    for (let x = region.x; x < region.x + region.width; x += 1) {
      if (x < 0 || y < 0 || x >= width || y >= height) {
        continue;
      }

      const pixelIndex = y * width + x;
      const alpha = data[pixelIndex * 4 + 3] ?? 255;

      mask[pixelIndex] = alpha > 16 ? 255 : 0;
    }
  }

  return mask;
}

function shouldKeepPixel(
  strategy: AutoStrategy,
  features: PixelFeatures,
  color: RgbColor,
  garmentColor: RgbColor,
  preserveWhiteInk: boolean,
  preserveBlackInk: boolean,
): boolean {
  if (isGarmentBasePixel(features, color, garmentColor)) {
    return false;
  }

  const garmentLuminance = getLuminance(garmentColor.r, garmentColor.g, garmentColor.b);
  const highSaturation = features.saturation > 0.24 && features.colorfulness > 34;
  const strongColor = features.saturation > 0.34 && features.colorfulness > 48;
  const darkInkOnLight = garmentLuminance > 150 && features.luminance < 132 && features.garmentDistance > 20;
  const blackLineOnLight =
    preserveBlackInk && garmentLuminance > 150 && features.luminance < 86 && features.localContrast > 12;
  const brightInkOnDark = garmentLuminance < 112 && features.luminance > 135 && features.garmentDistance > 22;
  const whiteInkOnDark =
    preserveWhiteInk && garmentLuminance < 128 && features.luminance > 210 && features.localContrast > 12;
  const strongContrast = features.garmentDistance > 48 || features.localContrast > 34;
  const colorfulDesign = highSaturation && (features.garmentDistance > 18 || features.localContrast > 16);

  if (strategy === "light_garment") {
    return darkInkOnLight || blackLineOnLight || colorfulDesign || (strongContrast && features.luminance < 190);
  }

  if (strategy === "dark_garment") {
    return brightInkOnDark || whiteInkOnDark || colorfulDesign || (strongContrast && features.luminance > 92);
  }

  if (strategy === "colorful_cartoon") {
    return strongColor || colorfulDesign || blackLineOnLight || whiteInkOnDark || features.localContrast > 46;
  }

  if (strategy === "center_design") {
    return colorfulDesign || darkInkOnLight || brightInkOnDark || features.garmentDistance > 42 || features.localContrast > 28;
  }

  if (strategy === "subject_design") {
    return (
      colorfulDesign ||
      darkInkOnLight ||
      brightInkOnDark ||
      blackLineOnLight ||
      whiteInkOnDark ||
      features.localContrast > 24 ||
      features.garmentDistance > 34
    );
  }

  return (
    (features.garmentDistance > 54 && (features.saturation > 0.1 || features.localContrast > 18)) ||
    (features.localContrast > 42 && features.garmentDistance > 18)
  );
}

function createStrategyMask(
  data: Buffer,
  width: number,
  height: number,
  strategy: AutoStrategy,
  backgroundColor: RgbColor,
  garmentColor: RgbColor,
  region: ProcessingBBox | null,
  preserveWhiteInk: boolean,
  preserveBlackInk: boolean,
): Uint8Array {
  const mask = new Uint8Array(width * height);
  const effectiveRegion = strategy === "center_design" && !region ? getCenterDesignRegion(width, height) : region;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (!isInsideRegion(x, y, effectiveRegion)) {
        continue;
      }

      const pixelIndex = y * width + x;
      const alpha = data[pixelIndex * 4 + 3] ?? 255;

      if (alpha < 16) {
        continue;
      }

      const color = getPixel(data, pixelIndex);
      const features = getPixelFeatures(data, width, height, pixelIndex, backgroundColor, garmentColor);

      mask[pixelIndex] = shouldKeepPixel(strategy, features, color, garmentColor, preserveWhiteInk, preserveBlackInk)
        ? 255
        : 0;
    }
  }

  return mask;
}

function scoreComponent(component: ConnectedComponent, width: number, height: number): number {
  const areaRatio = component.area / (width * height);
  const bboxAreaRatio = (component.bbox.width * component.bbox.height) / (width * height);
  const centerScore = componentCenterScore(component, width, height);
  const edgePenalty = componentTouchesEdge(component, width, height, Math.round(Math.min(width, height) * 0.015))
    ? 0.45
    : 1;
  const areaScore = areaRatio > 0.0008 && areaRatio < 0.42 ? 1 : 0.35;
  const bboxScore = bboxAreaRatio < 0.74 ? 1 : 0.35;

  return component.area * (0.45 + centerScore * 0.55) * edgePenalty * areaScore * bboxScore;
}

function cleanCandidateMask(mask: Uint8Array, width: number, height: number, minArea: number): Uint8Array {
  let output = removeSmallComponents(mask, width, height, minArea);

  output = keepScoredComponents(output, width, height, 36, (component) => scoreComponent(component, width, height));
  output = closeMask(output, width, height, 1);

  return output;
}

function createPriorityColorMask(
  data: Buffer,
  width: number,
  height: number,
  sourceMask: Uint8Array,
  backgroundColor: RgbColor,
  garmentColor: RgbColor,
  region: ProcessingBBox | null,
  preserveWhiteInk: boolean,
  preserveBlackInk: boolean,
): Uint8Array {
  const output = new Uint8Array(sourceMask.length);
  const effectiveRegion = region ?? getCenterDesignRegion(width, height);
  const garmentLuminance = getLuminance(garmentColor.r, garmentColor.g, garmentColor.b);

  for (let pixelIndex = 0; pixelIndex < sourceMask.length; pixelIndex += 1) {
    if (sourceMask[pixelIndex] === 0) {
      continue;
    }

    const x = pixelIndex % width;
    const y = Math.floor(pixelIndex / width);
    const features = getPixelFeatures(data, width, height, pixelIndex, backgroundColor, garmentColor);
    const inFocus = isInsideRegion(x, y, effectiveRegion);
    const colorful = features.saturation > 0.26 && features.colorfulness > 38 && features.garmentDistance > 18;
    const highContrastInk = features.garmentDistance > 58 || features.localContrast > 38;
    const lightInkOnDark =
      preserveWhiteInk && garmentLuminance < 128 && features.luminance > 200 && features.localContrast > 12;
    const darkInkOnLight =
      preserveBlackInk && garmentLuminance > 150 && features.luminance < 92 && features.localContrast > 12;

    if ((inFocus && (colorful || highContrastInk || lightInkOnDark || darkInkOnLight)) || colorful) {
      output[pixelIndex] = 255;
    }
  }

  return output;
}

function createSubjectDesignMask(
  data: Buffer,
  width: number,
  height: number,
  backgroundColor: RgbColor,
  garmentColor: RgbColor,
  region: ProcessingBBox | null,
  preserveWhiteInk: boolean,
  preserveBlackInk: boolean,
  minArea: number,
): { mask: Uint8Array; warning?: string } {
  const backgroundGarmentDistance = colorDistance(backgroundColor, garmentColor);
  const floodTolerance = backgroundGarmentDistance < 30 ? 22 : 38;
  const backgroundMask = createEdgeFloodBackgroundMask(data, width, height, backgroundColor, floodTolerance);
  let subjectMask = invertMask(backgroundMask);

  subjectMask = removeSmallComponents(subjectMask, width, height, minArea);
  subjectMask = keepScoredComponents(subjectMask, width, height, 12, (component) => {
    const areaRatio = component.area / (width * height);
    const edgePenalty = componentTouchesEdge(component, width, height, Math.round(Math.min(width, height) * 0.018))
      ? areaRatio > 0.08
        ? 0.28
        : 0.65
      : 1;

    return component.area * (0.5 + componentCenterScore(component, width, height) * 0.5) * edgePenalty;
  });
  subjectMask = closeMask(subjectMask, width, height, 1);

  const detailMask = createStrategyMask(
    data,
    width,
    height,
    "subject_design",
    backgroundColor,
    garmentColor,
    region,
    preserveWhiteInk,
    preserveBlackInk,
  );
  const priorityMask = createPriorityColorMask(
    data,
    width,
    height,
    subjectMask,
    backgroundColor,
    garmentColor,
    region,
    preserveWhiteInk,
    preserveBlackInk,
  );
  let designMask = combineMasks(subjectMask, combineMasks(detailMask, priorityMask, "or"), "and");

  designMask = cleanCandidateMask(designMask, width, height, minArea);

  const designStats = maskStats(designMask);

  if (designStats.ratio >= 0.002 && designStats.ratio <= 0.65) {
    return { mask: designMask };
  }

  return {
    mask: subjectMask,
    warning: "该图片更像3D商品效果图，已输出主体抠图，建议手动框选印花区域。",
  };
}

function refineLargePrintMask(
  data: Buffer,
  width: number,
  height: number,
  mask: Uint8Array,
  backgroundColor: RgbColor,
  garmentColor: RgbColor,
  region: ProcessingBBox | null,
  preserveWhiteInk: boolean,
  preserveBlackInk: boolean,
  minArea: number,
): { mask: Uint8Array; warning?: string } {
  if (maskStats(mask).ratio <= 0.75) {
    return { mask };
  }

  const priorityMask = createPriorityColorMask(
    data,
    width,
    height,
    mask,
    backgroundColor,
    garmentColor,
    region,
    preserveWhiteInk,
    preserveBlackInk,
  );
  let refined = combineMasks(mask, priorityMask, "and");

  if (maskStats(refined).ratio < 0.002) {
    refined = priorityMask;
  }

  refined = cleanCandidateMask(refined, width, height, minArea);

  if (maskStats(refined).ratio > 0.65) {
    refined = keepScoredComponents(refined, width, height, 24, (component) => {
      if (componentTouchesEdge(component, width, height, Math.round(Math.min(width, height) * 0.025))) {
        const areaRatio = component.area / (width * height);

        if (areaRatio > 0.05) {
          return 0;
        }
      }

      return scoreComponent(component, width, height);
    });
    refined = closeMask(refined, width, height, 1);
  }

  return { mask: refined, warning: "large_mask_refined" };
}

function calculateMaskMetrics(
  data: Buffer,
  width: number,
  height: number,
  mask: Uint8Array,
  backgroundColor: RgbColor,
  garmentColor: RgbColor,
  warning?: string,
): StrategyMetrics {
  const stats = maskStats(mask);
  const bbox = getMaskBBox(mask, width, height, 0);
  const bboxAreaRatio = bbox.width > 0 && bbox.height > 0 ? (bbox.width * bbox.height) / (width * height) : 0;
  const components = findConnectedComponents(mask, width, height);
  const largestComponentArea = components.reduce((largest, component) => Math.max(largest, component.area), 0);
  const componentCount = components.length;
  const centerScore =
    components.length === 0
      ? 0
      : components.reduce(
          (sum, component) => sum + componentCenterScore(component, width, height) * component.area,
          0,
        ) / Math.max(1, stats.nonZero);
  let colorScoreTotal = 0;
  let edgeScoreTotal = 0;
  let sampled = 0;
  const sampleStep = Math.max(1, Math.floor(stats.nonZero / 4000));

  for (let pixelIndex = 0; pixelIndex < mask.length; pixelIndex += 1) {
    if (mask[pixelIndex] === 0) {
      continue;
    }

    if (sampled % sampleStep !== 0) {
      sampled += 1;
      continue;
    }

    const features = getPixelFeatures(data, width, height, pixelIndex, backgroundColor, garmentColor);

    colorScoreTotal += clamp(features.saturation / 0.5, 0, 1) * 0.45 + clamp(features.garmentDistance / 115, 0, 1) * 0.55;
    edgeScoreTotal += clamp(features.localContrast / 72, 0, 1);
    sampled += 1;
  }

  const scoredSamples = Math.max(1, Math.ceil(sampled / sampleStep));
  const colorScore = clamp(colorScoreTotal / scoredSamples, 0, 1);
  const edgeScore = clamp(edgeScoreTotal / scoredSamples, 0, 1);
  const areaScore =
    stats.ratio >= 0.002 && stats.ratio <= 0.65
      ? 1
      : stats.ratio > 0.65 && stats.ratio <= 0.75
        ? 0.45
        : 0.1;
  const bboxScore = bboxAreaRatio > 0 && bboxAreaRatio <= 0.72 ? 1 : bboxAreaRatio <= 0.86 ? 0.45 : 0.1;
  const edgePenalty = components.some((component) => {
    const areaRatio = component.area / (width * height);

    return areaRatio > 0.08 && componentTouchesEdge(component, width, height, Math.round(Math.min(width, height) * 0.02));
  })
    ? 0.16
    : 0;
  const similarBackgroundAndGarment = colorDistance(backgroundColor, garmentColor) < 30;
  const centerWeight = similarBackgroundAndGarment ? 0.25 : 0.2;
  const colorWeight = similarBackgroundAndGarment ? 0.16 : 0.27;
  const edgeWeight = similarBackgroundAndGarment ? 0.27 : 0.16;
  const confidence = clamp(
    areaScore * 0.22 + bboxScore * 0.15 + centerScore * centerWeight + colorScore * colorWeight + edgeScore * edgeWeight - edgePenalty,
    0,
    1,
  );

  return {
    bboxAreaRatio,
    centerScore,
    colorScore,
    componentCount,
    confidence,
    edgeScore,
    largestComponentArea,
    maskAreaRatio: stats.ratio,
    warning,
  };
}

function resolveStrategyMode(mode: PrintExtractionMode): AutoStrategy {
  if (
    mode === "light_garment" ||
    mode === "dark_garment" ||
    mode === "high_contrast" ||
    mode === "colorful_cartoon" ||
    mode === "center_design" ||
    mode === "subject_design"
  ) {
    return mode;
  }

  if (mode === "product_render") {
    return "subject_design";
  }

  if (mode === "large_print") {
    return "high_contrast";
  }

  return "high_contrast";
}

function evaluateStrategy(
  data: Buffer,
  width: number,
  height: number,
  mode: AutoStrategy,
  backgroundColor: RgbColor,
  garmentColor: RgbColor,
  region: ProcessingBBox | null,
  preserveWhiteInk: boolean,
  preserveBlackInk: boolean,
  minArea: number,
): StrategyResult {
  if (mode === "subject_design") {
    const subjectResult = createSubjectDesignMask(
      data,
      width,
      height,
      backgroundColor,
      garmentColor,
      region,
      preserveWhiteInk,
      preserveBlackInk,
      minArea,
    );

    return {
      backgroundColor,
      garmentColor,
      mask: subjectResult.mask,
      metrics: calculateMaskMetrics(
        data,
        width,
        height,
        subjectResult.mask,
        backgroundColor,
        garmentColor,
        subjectResult.warning,
      ),
      selectedStrategy: "subject_design",
    };
  }

  const rawMask = createStrategyMask(
    data,
    width,
    height,
    mode,
    backgroundColor,
    garmentColor,
    region,
    preserveWhiteInk,
    preserveBlackInk,
  );
  let mask = cleanCandidateMask(rawMask, width, height, minArea);
  const refined = refineLargePrintMask(
    data,
    width,
    height,
    mask,
    backgroundColor,
    garmentColor,
    region,
    preserveWhiteInk,
    preserveBlackInk,
    minArea,
  );

  mask = refined.mask;

  return {
    backgroundColor,
    garmentColor,
    mask,
    metrics: calculateMaskMetrics(data, width, height, mask, backgroundColor, garmentColor, refined.warning),
    selectedStrategy: mode,
  };
}

function selectAutoStrategy(
  data: Buffer,
  width: number,
  height: number,
  backgroundColor: RgbColor,
  garmentColor: RgbColor,
  region: ProcessingBBox | null,
  preserveWhiteInk: boolean,
  preserveBlackInk: boolean,
  minArea: number,
): StrategyResult {
  const strategies: AutoStrategy[] = [
    "light_garment",
    "dark_garment",
    "colorful_cartoon",
    "high_contrast",
    "center_design",
    "subject_design",
  ];
  const results = strategies.map((strategy) =>
    evaluateStrategy(
      data,
      width,
      height,
      strategy,
      backgroundColor,
      garmentColor,
      region,
      preserveWhiteInk,
      preserveBlackInk,
      minArea,
    ),
  );

  const sortedResults = results.sort((a, b) => b.metrics.confidence - a.metrics.confidence);
  const validResult = sortedResults.find((result) => {
    const maxMaskRatio = result.selectedStrategy === "subject_design" ? 0.92 : 0.65;

    return result.metrics.maskAreaRatio >= 0.002 && result.metrics.maskAreaRatio <= maxMaskRatio && result.metrics.bboxAreaRatio > 0;
  });

  return validResult ?? sortedResults[0];
}

function getFailureMessage(metrics: StrategyMetrics, backgroundColor: RgbColor, garmentColor: RgbColor): string {
  if (metrics.maskAreaRatio < 0.002) {
    if (metrics.colorScore < 0.14 && metrics.edgeScore < 0.14) {
      return "图案和衣服颜色过于接近，建议切换高对比模式";
    }

    return "未检测到有效印花区域";
  }

  if (metrics.maskAreaRatio > 0.65) {
    if (colorDistance(backgroundColor, garmentColor) < 24) {
      return "背景和衣服颜色相似，建议使用手动框选";
    }

    return "印花区域过大，建议使用手动框选模式";
  }

  if (metrics.bboxAreaRatio <= 0 || metrics.bboxAreaRatio > 0.9) {
    return "印花区域过大，建议使用手动框选模式";
  }

  return "未检测到有效印花区域";
}

function validatePrintResult(result: StrategyResult, width: number, height: number, bbox: ProcessingBBox): void {
  const metrics = result.metrics;
  const maxMaskRatio = result.selectedStrategy === "subject_design" ? 0.92 : 0.65;
  const maxBBoxRatio = result.selectedStrategy === "subject_design" ? 0.96 : 0.9;

  if (
    metrics.maskAreaRatio < 0.002 ||
    metrics.maskAreaRatio > maxMaskRatio ||
    bbox.width <= 0 ||
    bbox.height <= 0 ||
    bbox.width > width ||
    bbox.height > height ||
    metrics.bboxAreaRatio > maxBBoxRatio
  ) {
    throw new Error(getFailureMessage(metrics, result.backgroundColor, result.garmentColor));
  }
}

function createResultMetrics(result: StrategyResult, requestedMode: PrintExtractionMode): Record<string, unknown> {
  const warning =
    result.metrics.warning ??
    (result.metrics.confidence < 0.45 ? "结果可能不理想，建议切换模式或手动框选。" : null);

  return {
    backgroundColor: result.backgroundColor,
    bboxAreaRatio: result.metrics.bboxAreaRatio,
    centerScore: result.metrics.centerScore,
    colorScore: result.metrics.colorScore,
    componentCount: result.metrics.componentCount,
    confidence: result.metrics.confidence,
    edgeScore: result.metrics.edgeScore,
    garmentColor: result.garmentColor,
    largestComponentArea: result.metrics.largestComponentArea,
    maskAreaRatio: result.metrics.maskAreaRatio,
    mode: requestedMode,
    selectedStrategy: result.selectedStrategy,
    warning,
  };
}

export async function extractPrintFromImage(input: PrintExtractionInput): Promise<PrintExtractionResult> {
  const maxSize = input.options?.maxSize ?? 1800;
  const padding = input.options?.padding ?? 8;
  const minComponentArea = input.options?.minComponentArea;
  const featherRadius = input.options?.featherRadius ?? 1;
  const preserveWhiteInk = input.options?.preserveWhiteInk ?? true;
  const preserveBlackInk = input.options?.preserveBlackInk ?? true;

  let normalizedBuffer: Buffer;

  try {
    const originalBuffer = await downloadImageBuffer(input.imageUrl);

    normalizedBuffer = await normalizeImage(originalBuffer, maxSize);
  } catch (error) {
    const message = error instanceof Error ? error.message : "";

    if (message.includes("Input buffer contains unsupported image format") || message.includes("unsupported image")) {
      throw new Error("图片不是有效图片");
    }

    throw error;
  }

  let loadedImage: Awaited<ReturnType<typeof loadImagePixels>>;

  try {
    loadedImage = await loadImagePixels(normalizedBuffer);
  } catch {
    throw new Error("图片不是有效图片");
  }

  const { data, height, width } = loadedImage;
  const manualRegion = input.manualRect ? safeBBox(input.manualRect, width, height) : null;
  const componentMinArea = minComponentArea ?? Math.max(12, Math.floor(width * height * 0.000025));

  if (input.mode === "manual_rect" && (!manualRegion || manualRegion.width <= 0 || manualRegion.height <= 0)) {
    throw new Error("未检测到有效印花区域");
  }

  const centerRegion = manualRegion ?? getCenterDesignRegion(width, height);
  const backgroundColor = estimateEdgeBackgroundColor(data, width, height);
  const garmentColor = estimateDominantRegionColor(data, width, height, centerRegion);
  const result =
    input.mode === "manual_rect" && manualRegion
      ? {
          backgroundColor,
          garmentColor,
          mask: cleanCandidateMask(createManualRectMask(data, width, height, manualRegion), width, height, componentMinArea),
          metrics: calculateMaskMetrics(
            data,
            width,
            height,
            createManualRectMask(data, width, height, manualRegion),
            backgroundColor,
            garmentColor,
          ),
          selectedStrategy: "manual_rect" as const,
        }
      : input.mode === "auto"
        ? selectAutoStrategy(
            data,
            width,
            height,
            backgroundColor,
            garmentColor,
            manualRegion,
            preserveWhiteInk,
            preserveBlackInk,
            componentMinArea,
          )
        : evaluateStrategy(
            data,
            width,
            height,
            resolveStrategyMode(input.mode),
            backgroundColor,
            garmentColor,
            manualRegion,
            preserveWhiteInk,
            preserveBlackInk,
            componentMinArea,
          );
  const bbox = getMaskBBox(result.mask, width, height, padding);

  validatePrintResult(result, width, height, bbox);

  const outputMask = featherRadius > 0 ? featherMask(result.mask, width, height, featherRadius) : result.mask;
  const rawData = applyAlphaMask(data, width, height, result.mask);
  const finalData = applyAlphaMask(data, width, height, outputMask);
  let rawPng = await rgbaToPng(rawData, width, height);
  let finalPng = await rgbaToPng(finalData, width, height);
  let maskPng = await makeMaskPng(outputMask, width, height);

  rawPng = await cropBufferByBBox(rawPng, bbox);
  finalPng = await cropBufferByBBox(finalPng, bbox);
  maskPng = await cropBufferByBBox(maskPng, bbox);

  return {
    bbox,
    finalPng,
    height: bbox.height,
    maskPng,
    metrics: createResultMetrics(result, input.mode),
    previewJpg: await makeWhitePreview(finalPng),
    rawPng,
    width: bbox.width,
  };
}
