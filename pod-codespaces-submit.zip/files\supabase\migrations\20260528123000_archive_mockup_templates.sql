alter table public.mockup_templates
  add column if not exists archived_at timestamptz,
  add column if not exists archived_reason text;

alter table public.mockup_templates
  alter column status set default 'active';

update public.mockup_templates
set status = 'active'
where status is null
  or status not in ('active', 'archived');

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'mockup_templates_status_check'
      and conrelid = 'public.mockup_templates'::regclass
  ) then
    alter table public.mockup_templates
      add constraint mockup_templates_status_check
      check (status in ('active', 'archived'));
  end if;
end $$;

create index if not exists mockup_templates_status_idx
  on public.mockup_templates(status);

create index if not exists mockup_templates_archived_at_idx
  on public.mockup_templates(archived_at);
