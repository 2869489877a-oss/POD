import "server-only";

import { randomUUID } from "crypto";

import sharp from "sharp";

import { calculatePrintPlacement } from "@/lib/mockups/placement";
import type { MockupScene } from "@/lib/mockups/scenes";
import type { createSupabaseServiceRoleClient } from "@/lib/supabase/server";

const ASSETS_BUCKET = "assets";

type SupabaseServiceClient = ReturnType<typeof createSupabaseServiceRoleClient>;

export type MockupPreviewResult = {
  error?: string;
  name: string;
  success: boolean;
  url?: string;
};

async function downloadImage(url: string) {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`图片下载失败：HTTP ${response.status}`);
  }

  return Buffer.from(await response.arrayBuffer());
}

function getErrorMessage(error: unknown) {
  if (error instanceof Error) {
    return error.message;
  }

  return "未知错误";
}

function safeName(value: string) {
  return value.trim().replace(/[^a-zA-Z0-9._-]/g, "-") || "scene";
}

export async function renderMockupPreviews(
  supabase: SupabaseServiceClient,
  templateId: string,
  scenes: MockupScene[],
  printBuffer: Buffer,
) {
  const results: MockupPreviewResult[] = [];
  const datePath = new Date().toISOString().slice(0, 10);

  for (const scene of scenes) {
    try {
      const backgroundBuffer = await downloadImage(scene.background_url);
      let image = sharp(backgroundBuffer)
        .rotate()
        .resize(scene.output_width, scene.output_height, {
          fit: "cover",
          position: "center",
        });

      if (scene.need_print && scene.print_area) {
        const printMetadata = await sharp(printBuffer).rotate().metadata();

        if (!printMetadata.width || !printMetadata.height) {
          throw new Error("印花图片尺寸读取失败");
        }

        const placement = calculatePrintPlacement({
          anchor: scene.anchor,
          fit: scene.fit,
          offsetX: scene.offset_x,
          offsetY: scene.offset_y,
          printArea: scene.print_area,
          printHeight: printMetadata.height,
          printWidth: printMetadata.width,
          scale: scene.scale,
        });
        const printLayer = await sharp(printBuffer)
          .rotate()
          .resize(placement.width, placement.height, {
            background: { alpha: 0, b: 0, g: 0, r: 0 },
            fit: scene.fit === "cover" ? "cover" : "fill",
            position: "center",
          })
          .rotate(scene.rotation, { background: { alpha: 0, b: 0, g: 0, r: 0 } })
          .png()
          .toBuffer();
        const layerMetadata = await sharp(printLayer).metadata();
        const layerWidth = layerMetadata.width ?? placement.width;
        const layerHeight = layerMetadata.height ?? placement.height;

        image = image.composite([
          {
            input: printLayer,
            left: Math.round(placement.left - (layerWidth - placement.width) / 2),
            top: Math.round(placement.top - (layerHeight - placement.height) / 2),
          },
        ]);
      }

      const outputBuffer = await image.png().toBuffer();
      const outputPath = `mockup-previews/${datePath}/${templateId}/${randomUUID()}-${safeName(
        scene.name,
      )}.png`;

      const { error: uploadError } = await supabase.storage
        .from(ASSETS_BUCKET)
        .upload(outputPath, outputBuffer, {
          contentType: "image/png",
          upsert: false,
        });

      if (uploadError) {
        throw new Error(`预览图上传失败：${uploadError.message}`);
      }

      const { data } = supabase.storage.from(ASSETS_BUCKET).getPublicUrl(outputPath);

      results.push({
        name: scene.name,
        success: true,
        url: data.publicUrl,
      });
    } catch (error) {
      results.push({
        error: getErrorMessage(error),
        name: scene.name,
        success: false,
      });
    }
  }

  return results;
}
