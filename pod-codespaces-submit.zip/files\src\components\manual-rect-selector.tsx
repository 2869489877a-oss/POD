"use client";

import type { CSSProperties, PointerEvent } from "react";
import { useMemo, useRef, useState } from "react";

export type ManualRect = {
  height: number;
  width: number;
  x: number;
  y: number;
};

type ManualRectSelectorProps = {
  filename: string;
  imageUrl: string;
  initialRect?: ManualRect | null;
  onClose: () => void;
  onSave: (rect: ManualRect) => void;
};

type ImageSize = {
  height: number;
  width: number;
};

type DragState = {
  startX: number;
  startY: number;
};

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function normalizeRect(rect: ManualRect, imageSize: ImageSize): ManualRect {
  const x = clamp(Math.round(rect.x), 0, Math.max(0, imageSize.width - 1));
  const y = clamp(Math.round(rect.y), 0, Math.max(0, imageSize.height - 1));
  const maxWidth = Math.max(0, imageSize.width - x);
  const maxHeight = Math.max(0, imageSize.height - y);

  return {
    height: clamp(Math.round(rect.height), 0, maxHeight),
    width: clamp(Math.round(rect.width), 0, maxWidth),
    x,
    y,
  };
}

function rectToStyle(rect: ManualRect, imageSize: ImageSize): CSSProperties {
  if (imageSize.width <= 0 || imageSize.height <= 0) {
    return {};
  }

  return {
    height: `${(rect.height / imageSize.height) * 100}%`,
    left: `${(rect.x / imageSize.width) * 100}%`,
    top: `${(rect.y / imageSize.height) * 100}%`,
    width: `${(rect.width / imageSize.width) * 100}%`,
  };
}

export function ManualRectSelector({
  filename,
  imageUrl,
  initialRect = null,
  onClose,
  onSave,
}: ManualRectSelectorProps) {
  const imageRef = useRef<HTMLImageElement | null>(null);
  const [imageSize, setImageSize] = useState<ImageSize>({ height: 0, width: 0 });
  const [rect, setRect] = useState<ManualRect>(initialRect ?? { height: 300, width: 300, x: 0, y: 0 });
  const [dragState, setDragState] = useState<DragState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const normalizedRect = useMemo(() => normalizeRect(rect, imageSize), [imageSize, rect]);

  function getNaturalPoint(clientX: number, clientY: number): { x: number; y: number } | null {
    const image = imageRef.current;

    if (!image || imageSize.width <= 0 || imageSize.height <= 0) {
      return null;
    }

    const bounds = image.getBoundingClientRect();

    if (bounds.width <= 0 || bounds.height <= 0) {
      return null;
    }

    return {
      x: clamp(Math.round(((clientX - bounds.left) / bounds.width) * imageSize.width), 0, imageSize.width),
      y: clamp(Math.round(((clientY - bounds.top) / bounds.height) * imageSize.height), 0, imageSize.height),
    };
  }

  function updateRectValue(key: keyof ManualRect, value: number) {
    setRect((current) => normalizeRect({ ...current, [key]: Math.max(0, value) }, imageSize));
  }

  function handlePointerDown(event: PointerEvent<HTMLDivElement>) {
    const point = getNaturalPoint(event.clientX, event.clientY);

    if (!point) {
      return;
    }

    setError(null);
    setDragState({ startX: point.x, startY: point.y });
    setRect({ height: 0, width: 0, x: point.x, y: point.y });
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function handlePointerMove(event: PointerEvent<HTMLDivElement>) {
    if (!dragState) {
      return;
    }

    const point = getNaturalPoint(event.clientX, event.clientY);

    if (!point) {
      return;
    }

    const x = Math.min(dragState.startX, point.x);
    const y = Math.min(dragState.startY, point.y);
    const width = Math.abs(point.x - dragState.startX);
    const height = Math.abs(point.y - dragState.startY);
    setRect(normalizeRect({ height, width, x, y }, imageSize));
  }

  function handlePointerUp(event: PointerEvent<HTMLDivElement>) {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }

    setDragState(null);
  }

  function handleSave() {
    const nextRect = normalizeRect(rect, imageSize);

    if (imageSize.width <= 0 || imageSize.height <= 0) {
      setError("图片还没有加载完成，请稍后再保存。");
      return;
    }

    if (nextRect.width <= 10 || nextRect.height <= 10) {
      setError("框选区域的宽度和高度必须大于 10 像素。");
      return;
    }

    onSave(nextRect);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-md bg-white shadow-xl">
        <div className="flex items-start justify-between gap-4 border-b border-zinc-200 px-5 py-4">
          <div>
            <h2 className="text-lg font-semibold text-zinc-950">框选印花区域</h2>
            <p className="mt-1 text-sm text-zinc-500">{filename}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md border border-zinc-300 px-3 py-2 text-sm font-medium text-zinc-800 hover:bg-zinc-100"
          >
            关闭
          </button>
        </div>

        <div className="grid gap-5 p-5 lg:grid-cols-[1fr_280px]">
          <div>
            <div
              role="presentation"
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
              className="relative mx-auto max-h-[70vh] w-full select-none overflow-hidden rounded-md border border-zinc-200 bg-zinc-100"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                ref={imageRef}
                src={imageUrl}
                alt={filename}
                draggable={false}
                onLoad={(event) => {
                  const image = event.currentTarget;
                  const nextSize = {
                    height: image.naturalHeight,
                    width: image.naturalWidth,
                  };

                  setImageSize(nextSize);
                  setRect((current) => normalizeRect(current, nextSize));
                }}
                className="block max-h-[70vh] w-full object-contain"
              />
              {imageSize.width > 0 && imageSize.height > 0 && normalizedRect.width > 0 && normalizedRect.height > 0 ? (
                <div
                  className="pointer-events-none absolute border-2 border-emerald-500 bg-emerald-400/20 shadow-[0_0_0_9999px_rgba(0,0,0,0.18)]"
                  style={rectToStyle(normalizedRect, imageSize)}
                />
              ) : null}
            </div>
            <p className="mt-2 text-sm text-zinc-500">
              可以直接拖拽画框，也可以在右侧输入原图真实像素坐标。
            </p>
          </div>

          <aside className="space-y-4">
            <div className="rounded-md bg-zinc-50 p-3 text-sm text-zinc-600">
              原图尺寸：{imageSize.width > 0 ? `${imageSize.width} x ${imageSize.height}` : "加载中..."}
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[
                ["x", "X"],
                ["y", "Y"],
                ["width", "宽"],
                ["height", "高"],
              ].map(([key, label]) => (
                <label key={key} className="block text-sm font-medium text-zinc-800">
                  {label}
                  <input
                    type="number"
                    min={0}
                    value={normalizedRect[key as keyof ManualRect]}
                    onChange={(event) => updateRectValue(key as keyof ManualRect, Number(event.target.value))}
                    className="mt-1 w-full rounded-md border border-zinc-300 px-3 py-2 text-sm"
                  />
                </label>
              ))}
            </div>

            <div className="rounded-md border border-zinc-200 p-3 text-xs text-zinc-500">
              当前区域：x={normalizedRect.x}，y={normalizedRect.y}，width={normalizedRect.width}，height=
              {normalizedRect.height}
            </div>

            {error ? (
              <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>
            ) : null}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleSave}
                className="flex-1 rounded-md bg-zinc-950 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-800"
              >
                保存框选
              </button>
              <button
                type="button"
                onClick={onClose}
                className="rounded-md border border-zinc-300 px-4 py-2 text-sm font-medium text-zinc-800 hover:bg-zinc-100"
              >
                取消
              </button>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
