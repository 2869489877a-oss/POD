import { NextResponse } from "next/server";

import { createSupabaseServiceRoleClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

const templateColumns = [
  "id",
  "name",
  "product_type",
  "scenes",
  "status",
  "archived_at",
  "archived_reason",
  "created_at",
  "updated_at",
].join(",");

function getTemplateId(request: Request) {
  const parts = new URL(request.url).pathname.split("/").filter(Boolean);
  const restoreIndex = parts.lastIndexOf("restore");
  return decodeURIComponent(parts[restoreIndex - 1] ?? "");
}

export async function POST(request: Request) {
  const templateId = getTemplateId(request);

  if (!templateId) {
    return NextResponse.json({ error: "缺少模板 ID" }, { status: 400 });
  }

  const supabase = createSupabaseServiceRoleClient();
  const { data, error } = await supabase
    .from("mockup_templates")
    .update({
      archived_at: null,
      archived_reason: null,
      status: "active",
    })
    .eq("id", templateId)
    .select(templateColumns)
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true, template: data });
}
