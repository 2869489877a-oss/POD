﻿# Codespaces 应用说明

1. 在 GitHub Codespaces 打开项目根目录。
2. 把 `pod-codespaces-submit.zip` 上传到 Codespaces 的项目根目录。
3. 在 Codespaces 终端执行：

```bash
unzip -o pod-codespaces-submit.zip -d /tmp/pod-codex
rsync -a /tmp/pod-codex/files/ ./
npm install
npm run lint
npm run build
git status
git add .
git commit -m "enhance image extraction and archive templates"
git push origin main
```

4. 如果没有 `rsync`，用：

```bash
cp -R /tmp/pod-codex/files/. ./
```

## 本次包含文件

- docs/DEPLOYMENT.md
- docs/PRODUCT_REQUIREMENTS.md
- docs/TEST_FEEDBACK_FIX_PLAN.md
- README.md
- src/app/api/assets/route.ts
- src/app/api/cutout/jobs/route.ts
- src/app/api/image-derivatives/[derivativeId]/set-preferred/route.ts
- src/app/api/mockup-jobs/route.ts
- src/app/api/mockup-templates/[templateId]/preview/route.ts
- src/app/api/mockup-templates/[templateId]/restore/route.ts
- src/app/api/mockup-templates/[templateId]/route.ts
- src/app/api/mockup-templates/route.ts
- src/app/api/print-extraction/jobs/route.ts
- src/app/cutout/page.tsx
- src/app/mockup-jobs/page.tsx
- src/app/mockup-templates/page.tsx
- src/app/print-extraction/page.tsx
- src/components/image-ai-processing-manager.tsx
- src/components/manual-rect-selector.tsx
- src/components/mockup-jobs-manager.tsx
- src/components/mockup-templates-manager.tsx
- src/lib/image-ai/color.ts
- src/lib/image-ai/components.ts
- src/lib/image-ai/crop.ts
- src/lib/image-ai/cutout.ts
- src/lib/image-ai/image-buffer.ts
- src/lib/image-ai/jobs.ts
- src/lib/image-ai/mask.ts
- src/lib/image-ai/morphology.ts
- src/lib/image-ai/output.ts
- src/lib/image-ai/print-extraction.ts
- src/lib/image-ai/types.ts
- src/lib/image-jobs/retry-failed.ts
- src/lib/mockups/mockup-job.ts
- src/lib/mockups/placement.ts
- src/lib/mockups/render-preview.ts
- src/lib/mockups/scenes.ts
- src/types/image-derivatives.ts
- supabase/migrations/20260528123000_archive_mockup_templates.sql
