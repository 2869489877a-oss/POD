import { NextResponse } from "next/server";

import { createSupabaseServiceRoleClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

const templateColumns = [
  "id",
  "name",
  "product_type",
  "scenes",
  "status",
  "archived_at",
  "archived_reason",
  "created_at",
  "updated_at",
].join(",");

function getTemplateId(request: Request) {
  const pathname = new URL(request.url).pathname;
  return decodeURIComponent(pathname.split("/").filter(Boolean).at(-1) ?? "");
}

export async function GET(request: Request) {
  const templateId = getTemplateId(request);

  if (!templateId) {
    return NextResponse.json({ error: "缺少模板 ID" }, { status: 400 });
  }

  const supabase = createSupabaseServiceRoleClient();
  const { data, error } = await supabase
    .from("mockup_templates")
    .select(templateColumns)
    .eq("id", templateId)
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ template: data });
}

async function getTemplateUsageCount(
  supabase: ReturnType<typeof createSupabaseServiceRoleClient>,
  templateId: string,
) {
  const { count, error } = await supabase
    .from("mockup_outputs")
    .select("id", { count: "exact", head: true })
    .eq("template_id", templateId);

  if (error) {
    throw new Error(error.message);
  }

  return count ?? 0;
}

export async function DELETE(request: Request) {
  const templateId = getTemplateId(request);

  if (!templateId) {
    return NextResponse.json({ error: "缺少模板 ID" }, { status: 400 });
  }

  let body: { dry_run?: unknown } = {};

  try {
    body = (await request.json()) as { dry_run?: unknown };
  } catch {
    body = {};
  }

  const supabase = createSupabaseServiceRoleClient();

  try {
    const { data: template, error: templateError } = await supabase
      .from("mockup_templates")
      .select("id,status")
      .eq("id", templateId)
      .maybeSingle();

    if (templateError) {
      throw new Error(templateError.message);
    }

    if (!template) {
      return NextResponse.json({ error: "模板不存在，请刷新后重试" }, { status: 404 });
    }

    const outputCount = await getTemplateUsageCount(supabase, templateId);

    if (body.dry_run === true) {
      return NextResponse.json({
        already_archived: template.status === "archived",
        output_count: outputCount,
        requires_confirmation: true,
      });
    }

    const { data, error } = await supabase
      .from("mockup_templates")
      .update({
        archived_at: new Date().toISOString(),
        archived_reason:
          outputCount > 0
            ? `用户归档模板。该模板已有 ${outputCount} 条套图生成记录。`
            : "用户归档模板。",
        status: "archived",
      })
      .eq("id", templateId)
      .select(templateColumns)
      .single();

    if (error) {
      throw new Error(error.message);
    }

    return NextResponse.json({
      ok: true,
      output_count: outputCount,
      template: data,
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "归档模板失败" },
      { status: 500 },
    );
  }
}
